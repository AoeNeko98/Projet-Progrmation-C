#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "login.h"
#include "interface.h"

typedef struct nom{
  char nom[20];
  char motdepasse[20];

}users ;

int verifierlogin(char username[], char password[])
{ int verif;
  users tableau[100];
  char util[20]; char passw[20];char no[20];char pn[20];char nu[20]; int role;
  int nbline=0; int i=0;
  FILE *f;

  f= fopen("user.txt","r");

  if (f != NULL)
  {
    while (fscanf(f,"%s %s %s %s %s \n",util,passw,no,pn,nu) != EOF)
    {
      nbline++;
      strcpy(tableau[i].nom, util);
      strcpy(tableau[i].motdepasse, passw);
      // printf("%s\n",tableau[i].nom);
       //printf("%s\n",tableau[i].motdepasse);
       printf("%d\n",strcmp(tableau[i].nom,username) );
      i++;
    }
    fclose(f);
  }

  for (i=0; i<nbline; i++)
  {
    if ((strcmp(tableau[i].nom,username)== 0) && (strcmp(tableau[i].motdepasse,password)== 0))
      {
      verif=3;

        return verif;
      }
      else
        {
          verif=-1;


        }
    }
    return verif;

  }
