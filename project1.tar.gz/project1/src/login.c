#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "login.h"
#include "interface.h"

typedef struct nom{
  char nom[20];
  char motdepasse[20];

}users ;

int verifierlogin(char username[], char password[])
{ int verif=-1;
  users tableau[100];users tableau1[100];users tableau2[100];
  char util[20]; char passw[20];char no[20];char pn[20];char nu[20]; int role;char util1[20]; char passw1[20];char util2[20]; char passw2[20];
  int nbline=0; int i=0; int nbline1=0; int i1=0; int nbline2=0; int i2=0;
  FILE *f; FILE *f1;FILE *f2;
  f2= fopen("agent.txt","r");

  if (f2 != NULL)
  {
    while (fscanf(f2,"%s %s \n",util2,passw2) != EOF)
    {
      nbline2++;
      strcpy(tableau2[i2].nom, util2);
      strcpy(tableau2[i2].motdepasse, passw2);

      i2++;
    }
  }
    fclose(f2);

  f1= fopen("admin.txt","r");

  if (f1 != NULL)
  {
    while (fscanf(f1,"%s %s \n",util1,passw1) != EOF)
    {
      nbline1++;
      strcpy(tableau1[i1].nom, util1);
      strcpy(tableau1[i1].motdepasse, passw1);

      i1++;
    }
  }
    fclose(f1);
  f= fopen("user.txt","r");

  if (f != NULL)
  {
    while (fscanf(f,"%s %s %s %s %s \n",util,passw,no,pn,nu) != EOF)
    {
      nbline++;
      strcpy(tableau[i].nom, util);
      strcpy(tableau[i].motdepasse, passw);

      i++;
    }
    fclose(f);
  }
 for (i=0; i<(nbline2); i++)

  {
    if ((strcmp(tableau2[i].nom,username)== 0) && (strcmp(tableau2[i].motdepasse,password)== 0))
      {
      verif=2;
      }

    }
    for (i=0; i<(nbline1); i++)

     {
       if ((strcmp(tableau1[i].nom,username)== 0) && (strcmp(tableau1[i].motdepasse,password)== 0))
         {
         verif=1;
         }

       }

  for (i=0; i<(nbline); i++)

  {
    if ((strcmp(tableau[i].nom,username)== 0) && (strcmp(tableau[i].motdepasse,password)== 0))
      {
      verif=3;
      }

    }
    return verif;

  }
