#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

struct reponse
{
	char id_rp[20];
	char nom_rp[3000];



};
enum
{
  COL_ID_rp=0,
  COL_NOM_rp,



  COLUMNS_RP
} ;
typedef struct reponse rp;
static GtkTreeModel * create_and_fill_model_rp(GtkWidget *treeview_rp, rp T[]);
static GtkWidget * create_view_and_model_rp (GtkWidget *treeview_rp, rp T[]);
void affichagerp (GtkWidget *treeview_rp, rp T[]);
void lecture_rp(FILE *k, rp T[]);
