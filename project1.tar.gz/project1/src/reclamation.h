#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

struct reclamation
{
	char id_re[20];
	char nom_re[3000];



};
enum
{
  COL_ID_re=0,
  COL_NOM_re,



  COLUMNS_RE
} ;
typedef struct reclamation re;
static GtkTreeModel * create_and_fill_model_re(GtkWidget *treeview_re, re T[]);
static GtkWidget * create_view_and_model_re (GtkWidget *treeview_re, re T[]);
void affichagere (GtkWidget *treeview_re, re T[]);
void lecture_re(FILE *r, re T[]);
