#include "personne.h"



void ajouter_c(per cl)
{
  FILE *f;
  char role[10]="3";

  f=fopen("user.txt","a+");

  if (f != NULL)
  {
    fprintf(f,"%s %s %s %s %s \n",cl.username,cl.password,cl.nom,cl.prenom,cl.tel);
    fclose(f);
  }

}




int verifierexistant (char username[])
{
  int verif =-1;
  per tableau[100];
  FILE *f;
  char user[200];
  int nbline=0, i=0;

  f= fopen("user.txt","r");

  if (f != NULL)
    {
      while (fscanf(f,"%s",user) != EOF)
      {
        nbline ++;
        strcpy(tableau[i].username ,user);
        i++;
      }
      fclose(f);
    }
  for (i =0; i<nbline; i++)
    {
      if (strcmp(username, tableau[i].username) == 0)
        {
          verif = 0; //Existant
          break;
        }
      else
      {
        verif =1; //inéxistant
      }
    }
  return verif;
}
