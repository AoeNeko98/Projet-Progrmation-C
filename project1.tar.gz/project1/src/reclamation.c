#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "reclamation.h"



static GtkTreeModel * create_and_fill_model_re (GtkWidget *treeview_re,re T[])
{
  GtkListStore  *store;
  GtkTreeIter    iter;
  int i,nbline=0;
  char c;
  char filename[20]="reclamation.txt";
  FILE *r;
  r=fopen(filename,"r");

				while((c=fgetc(r))!=EOF)
        				{
          				  if (c=='\n')
           					 nbline++;
        				}


  store = gtk_list_store_new (COLUMNS_RE, G_TYPE_STRING, G_TYPE_STRING);

  /* Append a row and fill in some data */
  for(i=0;i<nbline;i++)
 {
  gtk_list_store_append (store, &iter);
  gtk_list_store_set (store, &iter, COL_ID_re , T[i].id_re, COL_NOM_re, T[i].nom_re,-1);

}

  return GTK_TREE_MODEL (store);
}


static GtkWidget * create_view_and_model_re (GtkWidget *treeview_re, re T[])
{
  GtkTreeViewColumn   *col;
  GtkCellRenderer     *renderer;
  GtkTreeModel        *model;

  /* --- Colonne 1 --- */

  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_re),
                                               -1,
                                               "ID",
                                               renderer,
                                               "text", COL_ID_re,
                                               NULL);

  /* --- Colonne 2 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_re),
                                               -1,
                                               "CONTENUE",
                                               renderer,
                                               "text", COL_NOM_re,
                                               NULL);





  model = create_and_fill_model_re (treeview_re,T);

  gtk_tree_view_set_model (GTK_TREE_VIEW (treeview_re), model);

  g_object_unref (model); /* destroy model automatically with view */



  return (treeview_re);
}
void lecture_re(FILE *r,re T[])
{
		char filename[20]="reclamation.txt";
	char ide[20];
	char nom[3000];



		int i=0;
		r=fopen(filename,"r");

			while (fscanf(r, "%s %s \n",ide,nom) != EOF )
				 {


				   strcpy(T[i].id_re, ide);
				   strcpy(T[i].nom_re, nom);





				   i++;
				 }
			fclose(r);
	}
void affichagere (GtkWidget *treeview_re, re T[])
{
  treeview_re = create_view_and_model_re(treeview_re,T);
}
