#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "reponse.h"



static GtkTreeModel * create_and_fill_model_rp (GtkWidget *treeview_rp,rp T[])
{
  GtkListStore  *store;
  GtkTreeIter    iter;
  int i,nbline=0;
  char c;
  char filename[20]="reponse.txt";
  FILE *k;
  k=fopen(filename,"r");

				while((c=fgetc(k))!=EOF)
        				{
          				  if (c=='\n')
           					 nbline++;
        				}


  store = gtk_list_store_new (COLUMNS_RP, G_TYPE_STRING, G_TYPE_STRING);

  /* Append a row and fill in some data */
  for(i=0;i<nbline;i++)
 {
  gtk_list_store_append (store, &iter);
  gtk_list_store_set (store, &iter, COL_ID_rp , T[i].id_rp, COL_NOM_rp, T[i].nom_rp,-1);

}

  return GTK_TREE_MODEL (store);
}


static GtkWidget * create_view_and_model_rp (GtkWidget *treeview_rp, rp T[])
{
  GtkTreeViewColumn   *col;
  GtkCellRenderer     *renderer;
  GtkTreeModel        *model;

  /* --- Colonne 1 --- */

  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_rp),
                                               -1,
                                               "ID",
                                               renderer,
                                               "text", COL_ID_rp,
                                               NULL);

  /* --- Colonne 2 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_rp),
                                               -1,
                                               "REPONSE",
                                               renderer,
                                               "text", COL_NOM_rp,
                                               NULL);





  model = create_and_fill_model_rp (treeview_rp,T);

  gtk_tree_view_set_model (GTK_TREE_VIEW (treeview_rp), model);

  g_object_unref (model); /* destroy model automatically with view */



  return (treeview_rp);
}
void lecture_rp(FILE *k,rp T[])
{
		char filename[20]="reponse.txt";
	char ide[20];
	char nom[3000];



		int i=0;
		k=fopen(filename,"r");

			while (fscanf(k, "%s %s \n",ide,nom) != EOF )
				 {


				   strcpy(T[i].id_rp, ide);
				   strcpy(T[i].nom_rp, nom);





				   i++;
				 }
			fclose(k);
	}
void affichagerp (GtkWidget *treeview_rp, rp T[])
{
  treeview_rp = create_view_and_model_rp(treeview_rp,T);
}
