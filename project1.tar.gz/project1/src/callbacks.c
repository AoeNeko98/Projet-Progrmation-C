#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void on_client_show                         (GtkWidget *objet_graphique,  gpointer user_data)
{
GtkWidget *treeview_hotel;  GtkWidget *treeview_ex;GtkWidget *treeview_vol;GtkWidget *treeview_re;GtkWidget *treeview_rp;GtkWidget *treeview_vo;
 FILE *f; FILE *v;FILE *p;FILE *r;FILE *k;FILE *j;
hotel T[200];vol H[200];ex E[200];re M[200];rp J[200];vo K[200];
treeview_hotel = lookup_widget (GTK_WIDGET(objet_graphique),"treeview_h");
treeview_vol = lookup_widget (GTK_WIDGET(objet_graphique),"treeview5");
treeview_ex = lookup_widget (GTK_WIDGET(objet_graphique),"treeview_e");
treeview_re = lookup_widget (GTK_WIDGET(objet_graphique),"treeview_rec");
treeview_rp = lookup_widget (GTK_WIDGET(objet_graphique),"treeview_rep");
treeview_vo = lookup_widget (GTK_WIDGET(objet_graphique),"treeview_loc");

lecture_hotel(f,T);
affichagehotel (treeview_hotel ,T);

lecture_vol(v,H);
affichagevol (treeview_vol ,H);

lecture_ex(p,E);
affichageex (treeview_ex ,E);

lecture_re(r,M);
affichagere (treeview_re ,M);

lecture_rp(k,J);
affichagerp (treeview_rp ,J);

lecture_vo(j,K);
affichagevo (treeview_vo ,K);

}

void
on_button7_clicked                     (GtkWidget *objet_graphique,  gpointer user_data)
{
  GtkWidget *input1;
  GtkWidget *input2;
  GtkWidget *input3;
  GtkWidget *input4;
  GtkWidget *input5;
  GtkWidget *output;
    char name1[20]; char last1[20];char tel1[20];char username1[20]; char password1[20];
 input1 = lookup_widget(objet_graphique, "entry_ea_nom");
 input2 = lookup_widget(objet_graphique, "entry_ea_prenom");
 input3 = lookup_widget(objet_graphique, "entry_ea_login");
 input4 = lookup_widget(objet_graphique, "entry_ea_mdp");
 input5 = lookup_widget(objet_graphique, "entry_ea_tel");
 output= lookup_widget(objet_graphique, "label152");
 strcpy(last1, gtk_entry_get_text(GTK_ENTRY(input1)));
 strcpy(name1, gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(username1, gtk_entry_get_text(GTK_ENTRY(input3)));
   strcpy(password1, gtk_entry_get_text(GTK_ENTRY(input4)));
    strcpy(tel1, gtk_entry_get_text(GTK_ENTRY(input5)));
   if (verifierexistant(username1)== 0)
    {
        gtk_label_set_text(GTK_LABEL(output), "Nom d'utilsateur déjà utilisé !");
    }
    else
 { per p;
   strcpy(p.nom,name1);
    strcpy(p.prenom,last1);
    strcpy(p.username,username1);
    strcpy(p.password,password1);
    strcpy(p.tel,tel1);
    ajouter_c(p);
    GtkWidget *authentification;
  GtkWidget *Ajout_clients;


authentification= create_authentification ();
gtk_widget_show (authentification);

Ajout_clients=lookup_widget(objet_graphique,"Ajout_clients");
gtk_widget_destroy (Ajout_clients);




}
}

void on_button16_clicked                    (GtkWidget *objet_graphique,  gpointer user_data)
{
  GtkWidget *authentification;
GtkWidget *client;


authentification= create_authentification ();
gtk_widget_show (authentification);

client=lookup_widget(objet_graphique,"client");
gtk_widget_destroy (client);

}

void on_button_inscri_clicked               (GtkWidget *objet_graphique,  gpointer user_data)
{
  GtkWidget *authentification;
GtkWidget *Ajout_clients;


Ajout_clients= create_Ajout_clients ();
gtk_widget_show (Ajout_clients);

authentification=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy (authentification);

}
