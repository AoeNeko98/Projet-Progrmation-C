#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "hotel.h"
#include "vol.h"
#include "excursion.h"
#include "reclamation.h"
#include "reponse.h"
#include "voiture.h"
#include "personne.h"







void on_client_show                         (GtkWidget *objet_graphique,  gpointer user_data);

void on_button7_clicked                     (GtkWidget *objet_graphique,  gpointer user_data);

void on_button16_clicked                    (GtkWidget *objet_graphique,  gpointer user_data);

void on_button_inscri_clicked               (GtkWidget *objet_graphique,  gpointer user_data);
