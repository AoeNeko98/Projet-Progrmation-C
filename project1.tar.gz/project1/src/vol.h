#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

struct vol
{
	char id_v[20];
	char nom_v[20];
	char prix_v[20];
	char ville_v[20];

};
enum
{
  COL_ID_V=0,
  COL_NOM_V,
  COL_PRIX_V,
  COL_VILLE_V,

  COLUMNS_VOL
} ;
typedef struct vol vol;
static GtkTreeModel * create_and_fill_model_vol(GtkWidget *treeview_vol,vol T[]);
static GtkWidget * create_view_and_model_vol (GtkWidget *treeview_vol, vol T[]);
void affichagevol (GtkWidget *treeview_vol, vol T[]);
void lecture_vol(FILE *f, vol T[]);
