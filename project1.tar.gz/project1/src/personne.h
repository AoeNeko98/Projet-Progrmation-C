#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#define sz 20

struct personne{
  char username[sz];
  char password[sz];
  char nom[sz];
  char prenom[sz];
  char tel[sz];
};

typedef struct personne per;
void ajouter_c(per);
void modifier_c(per);
void supprimer_c(char username[]);
per chercher(char x[]);

int verifierexistant (char username[]);
