#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#define sz 20

struct personne{
  char username[sz];
  char password[sz];
  char nom[sz];
  char prenom[sz];
  char tel[sz];
};

typedef struct personne per;
void ajouter_c();
void supprimer(char log[]);
per chercher(char x[]);
void ajouterlogin (char username[], char password[], int role);
int verifierexistant (char username[]);
