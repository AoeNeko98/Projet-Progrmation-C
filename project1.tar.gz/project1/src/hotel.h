#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

struct hotel
{
	char id[20];
	char nom_h[20];
	char prix_h[20];
	char ville_h[20];
	char nb_etoile_h[20];
};
enum
{
  COL_ID=0,
  COL_NOM,
  COL_PRIX,
  COL_VILLE,
  COL_NB,
  COLUMNS_HOTEL
} ;
typedef struct hotel hotel;
static GtkTreeModel * create_and_fill_model_hotel (GtkWidget *treeview_hotel,hotel T[]);
static GtkWidget * create_view_and_model_hotel (GtkWidget *treeview_hotel, hotel T[]);
void affichagehotel (GtkWidget *treeview_hotel, hotel T[]);
void lecture_hotel(FILE *f, hotel T[]);
