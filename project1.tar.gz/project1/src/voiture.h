#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

struct voiture
{
	char id_vo[20];
	char nom_vo[20];
	char prix_vo[20];
	char mat_vo[20];

};
enum
{
  COL_ID_vo=0,
  COL_NOM_vo,
  COL_PRIX_vo,
  COL_MAT_vo,

  COLUMNS_VOITURE
} ;
typedef struct voiture vo;
static GtkTreeModel * create_and_fill_model_vo(GtkWidget *treeview_vo,vo T[]);
static GtkWidget * create_view_and_model_vo (GtkWidget *treeview_vo, vo T[]);
void affichagevo (GtkWidget *treeview_vo, vo T[]);
void lecture_vo(FILE *f, vo T[]);
