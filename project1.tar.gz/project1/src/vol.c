#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "vol.h"



static GtkTreeModel * create_and_fill_model_vol (GtkWidget *treeview_vol,vol T[])
{
  GtkListStore  *store;
  GtkTreeIter    iter;
  int i,nbline=0;
  char c;
  char filename[20]="vol.txt";
  FILE *f;
  f=fopen(filename,"r");

				while((c=fgetc(f))!=EOF)
        				{
          				  if (c=='\n')
           					 nbline++;
        				}


  store = gtk_list_store_new (COLUMNS_VOL, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

  /* Append a row and fill in some data */
  for(i=0;i<nbline;i++)
 {
  gtk_list_store_append (store, &iter);
  gtk_list_store_set (store, &iter, COL_ID_V , T[i].id_v, COL_NOM_V, T[i].nom_v, COL_PRIX_V, T[i].prix_v, COL_VILLE_V, T[i].ville_v,-1);

}

  return GTK_TREE_MODEL (store);
}


static GtkWidget * create_view_and_model_vol (GtkWidget *treeview_vol, vol T[])
{
  GtkTreeViewColumn   *col;
  GtkCellRenderer     *renderer;
  GtkTreeModel        *model;

  /* --- Colonne 1 --- */

  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vol),
                                               -1,
                                               "N°VOL",
                                               renderer,
                                               "text", COL_ID_V,
                                               NULL);

  /* --- Colonne 2 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vol),
                                               -1,
                                               "AIRLINE",
                                               renderer,
                                               "text", COL_NOM_V,
                                               NULL);

/* --- Colonne 3 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vol),
                                               -1,
                                               "BILLET",
                                               renderer,
                                               "text", COL_PRIX_V,
                                               NULL);

/* --- Colonne 4 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vol),
                                               -1,
                                               "DESTINATION",
                                               renderer,
                                               "text", COL_VILLE_V,
                                               NULL);


  model = create_and_fill_model_vol (treeview_vol,T);

  gtk_tree_view_set_model (GTK_TREE_VIEW (treeview_vol), model);

  g_object_unref (model); /* destroy model automatically with view */



  return (treeview_vol);
}
void lecture_vol(FILE *f,vol T[])
{
		char filename[20]="vol.txt";
	char ide[20];
	char nom[20];
	char prix[20];
	char ville[20];


		int i=0;
		f=fopen(filename,"r");

			while (fscanf(f, "%s %s %s %s  \n",ide,nom,prix,ville) != EOF )
				 {


				   strcpy(T[i].id_v, ide);
				   strcpy(T[i].nom_v, nom);
					 strcpy(T[i].prix_v, prix);
				   strcpy(T[i].ville_v, ville);



				   i++;
				 }
			fclose(f);
	}
void affichagevol (GtkWidget *treeview_vol, vol T[])
{
  treeview_vol = create_view_and_model_vol(treeview_vol,T);
}
