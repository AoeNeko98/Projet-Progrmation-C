#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "excursion.h"



static GtkTreeModel * create_and_fill_model_ex (GtkWidget *treeview_ex,ex T[])
{
  GtkListStore  *store;
  GtkTreeIter    iter;
  int i,nbline=0;
  char c;
  char filename[20]="excursion.txt";
  FILE *p;
  p=fopen(filename,"r");

				while((c=fgetc(p))!=EOF)
        				{
          				  if (c=='\n')
           					 nbline++;
        				}


  store = gtk_list_store_new (COLUMNS_EX, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

  /* Append a row and fill in some data */
  for(i=0;i<nbline;i++)
 {
  gtk_list_store_append (store, &iter);
  gtk_list_store_set (store, &iter, COL_ID_ex , T[i].id_ex, COL_NOM_ex, T[i].nom_ex, COL_PRIX_ex, T[i].prix_ex,-1);

}

  return GTK_TREE_MODEL (store);
}


static GtkWidget * create_view_and_model_ex (GtkWidget *treeview_ex, ex T[])
{
  GtkTreeViewColumn   *col;
  GtkCellRenderer     *renderer;
  GtkTreeModel        *model;

  /* --- Colonne 1 --- */

  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_ex),
                                               -1,
                                               "ID",
                                               renderer,
                                               "text", COL_ID_ex,
                                               NULL);

  /* --- Colonne 2 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_ex),
                                               -1,
                                               "VILLE",
                                               renderer,
                                               "text", COL_NOM_ex,
                                               NULL);

/* --- Colonne 3 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_ex),
                                               -1,
                                               "PRIX",
                                               renderer,
                                               "text", COL_PRIX_ex,
                                               NULL);




  model = create_and_fill_model_ex (treeview_ex,T);

  gtk_tree_view_set_model (GTK_TREE_VIEW (treeview_ex), model);

  g_object_unref (model); /* destroy model automatically with view */



  return (treeview_ex);
}
void lecture_ex(FILE *p,ex T[])
{
		char filename[20]="excursion.txt";
	char ide[20];
	char nom[20];
	char prix[20];
	char ville[20];


		int i=0;
		p=fopen(filename,"r");

			while (fscanf(p, "%s %s %s\n",ide,nom,prix) != EOF )
				 {


				   strcpy(T[i].id_ex, ide);
				   strcpy(T[i].nom_ex, nom);
					 strcpy(T[i].prix_ex, prix);




				   i++;
				 }
			fclose(p);
	}
void affichageex (GtkWidget *treeview_ex, ex T[])
{
  treeview_ex = create_view_and_model_ex(treeview_ex,T);
}
