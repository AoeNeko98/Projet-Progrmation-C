#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "voiture.h"



static GtkTreeModel * create_and_fill_model_vo (GtkWidget *treeview_vo,vo T[])
{
  GtkListStore  *store;
  GtkTreeIter    iter;
  int i,nbline=0;
  char c;
  char filename[20]="voiture.txt";
  FILE *j;
  j=fopen(filename,"r");

				while((c=fgetc(j))!=EOF)
        				{
          				  if (c=='\n')
           					 nbline++;
        				}


  store = gtk_list_store_new (COLUMNS_VOITURE, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

  /* Append a row and fill in some data */
  for(i=0;i<nbline;i++)
 {
  gtk_list_store_append (store, &iter);
  gtk_list_store_set (store, &iter, COL_ID_vo , T[i].id_vo, COL_NOM_vo, T[i].nom_vo, COL_PRIX_vo, T[i].prix_vo, COL_MAT_vo, T[i].mat_vo,-1);

}

  return GTK_TREE_MODEL (store);
}


static GtkWidget * create_view_and_model_vo (GtkWidget *treeview_vo, vo T[])
{
  GtkTreeViewColumn   *col;
  GtkCellRenderer     *renderer;
  GtkTreeModel        *model;

  /* --- Colonne 1 --- */

  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vo),
                                               -1,
                                               "ID",
                                               renderer,
                                               "text", COL_ID_vo,
                                               NULL);

  /* --- Colonne 2 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vo),
                                               -1,
                                               "MARQUE",
                                               renderer,
                                               "text", COL_NOM_vo,
                                               NULL);

/* --- Colonne 3 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vo),
                                               -1,
                                               "PRIX",
                                               renderer,
                                               "text", COL_PRIX_vo,
                                               NULL);

/* --- Colonne 4 --- */

  col = gtk_tree_view_column_new();
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (treeview_vo),
                                               -1,
                                               "MATRICULE",
                                               renderer,
                                               "text", COL_MAT_vo,
                                               NULL);


  model = create_and_fill_model_vo (treeview_vo,T);

  gtk_tree_view_set_model (GTK_TREE_VIEW (treeview_vo), model);

  g_object_unref (model); /* destroy model automatically with view */



  return (treeview_vo);
}
void lecture_vo(FILE *j,vo T[])
{
		char filename[20]="voiture.txt";
	char ide[20];
	char nom[20];
	char prix[20];
	char mat[20];


		int i=0;
		j=fopen(filename,"r");

			while (fscanf(j, "%s %s %s %s  \n",ide,nom,prix,mat) != EOF )
				 {


				   strcpy(T[i].id_vo, ide);
				   strcpy(T[i].nom_vo, nom);
					 strcpy(T[i].prix_vo, prix);
				   strcpy(T[i].mat_vo, mat);



				   i++;
				 }
			fclose(j);
	}
void affichagevo (GtkWidget *treeview_vo, vo T[])
{
  treeview_vo = create_view_and_model_vo(treeview_vo,T);
}
