#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int verifierlogin(char username[], char password[]);
