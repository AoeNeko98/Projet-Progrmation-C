#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

struct excursion
{
	char id_ex[20];
	char nom_ex[20];
	char prix_ex[20];


};
enum
{
  COL_ID_ex=0,
  COL_NOM_ex,
  COL_PRIX_ex,


  COLUMNS_EX
} ;
typedef struct excursion ex;
static GtkTreeModel * create_and_fill_model_ex(GtkWidget *treeview_ex, ex T[]);
static GtkWidget * create_view_and_model_ex (GtkWidget *treeview_ex, ex T[]);
void affichageex (GtkWidget *treeview_ex, ex T[]);
void lecture_ex(FILE *p, ex T[]);
